import React from "react";
import RegisterComponent from "../components/RegisterComponent";

export default function Register() {
  return <RegisterComponent />;
}
