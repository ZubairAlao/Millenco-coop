export const environment = {
  firebase: {
    //Your Own
  },
  production: true
};
